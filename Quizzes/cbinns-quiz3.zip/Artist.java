/**
 * Created by cbinns on 1/17/2018.
 */

public class Artist extends Employee {

    public Artist() {

    }
}
